<?php
    $con=mysqli_connect("localhost", "root", "", "spark_system") or die(mysqli_error());
?>